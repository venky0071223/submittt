//
//  LocationManager.swift
//  LocationTest
//
//  Created by venky N on 18/11/22.
//

import CoreLocation

let locationService = UserLocationServices(with: CLLocationManager())
var locationCoordinates: UserLocation?

typealias Coordinate = CLLocationCoordinate2D

protocol UserLocation {
    var coordinate: Coordinate { get }
}

extension CLLocation: UserLocation { }

enum UserLocationError: Swift.Error {
    case canNotBeLocated
}
typealias UserLocationCompletionBlock = (UserLocation?, UserLocationError?) -> Void
//let locationService =
protocol UserLocationProvider {
    func findUserLocation(then: @escaping UserLocationCompletionBlock)
}

protocol LocationProvider {
    var isUserAuthorized: Bool{ get }
    func requestwhenInuseAuthorization()
    func startUpdatingLocation()
}

extension CLLocationManager: LocationProvider {
    func requestwhenInuseAuthorization() {
    }
    
    var isUserAuthorized: Bool {
        return CLLocationManager.authorizationStatus() == .authorizedWhenInUse
    }
}
class UserLocationServices: NSObject, UserLocationProvider {

    
    fileprivate var provider: LocationProvider
    fileprivate var locationCompletionBlock: UserLocationCompletionBlock?
    
    init(with provider: LocationProvider) {
        self.provider = provider
        super.init()
    }
    
    
    func findUserLocation(then: @escaping UserLocationCompletionBlock) {
        locationCompletionBlock = then
        sendLocationData(data: nil, error: nil)
    }
    
    private func askForLocationAccess() {
         (CLLocationManager.authorizationStatus() == .denied) ? locationCompletionBlock?(nil, .canNotBeLocated) : provider.requestwhenInuseAuthorization()
    }
    
    private func sendLocationData(data: UserLocation?, error: UserLocationError?) {
        locationCompletionBlock?(data, error)
        locationCompletionBlock = nil
    }
}

extension UserLocationServices: CLLocationManagerDelegate {
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        } else if manager.authorizationStatus == .denied {
            locationCompletionBlock?(nil, .canNotBeLocated)
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        manager.stopUpdatingLocation()
        if let location =  locations.last {
            sendLocationData(data: location, error: nil)
        } else {
            locationCompletionBlock?(nil, .canNotBeLocated)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationCompletionBlock?(nil, .canNotBeLocated)
    }
}
